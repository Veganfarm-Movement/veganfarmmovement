-- VEGANFARM core schema. Run in Supabase SQL editor. No adoption tables by design.
create extension if not exists pgcrypto;
create type case_status as enum ('pending_review','approved','published','urgent','fully_funded','completed','rejected','archived');
create type donation_status as enum ('pending_verification','verified','rejected');
create type donation_category as enum ('animal_welfare','human_welfare');
create table profiles (id uuid primary key references auth.users on delete cascade, full_name text, role text not null default 'founder' check (role in ('founder')));
create table team_access_settings (id int primary key default 1 check (id=1), code_hash text not null, enabled boolean not null default true, updated_at timestamptz default now());
create table team_login_attempts (id bigserial primary key, ip text, at timestamptz default now());
create sequence case_seq;
create table rescue_cases (
  id uuid primary key default gen_random_uuid(),
  case_code text unique not null default ('VF-'||extract(year from now())::int||'-'||lpad(nextval('case_seq')::text,4,'0')),
  animal_name text, animal_type text not null check (animal_type in ('dog','cat','cow','other')),
  location text not null, condition text not null, description text not null, rescue_date date,
  hospital text, treatment_required text, treatment_status text,
  diagnosis text, symptoms text, treatment_given text, treatment_pending text, estimated_cost numeric check (estimated_cost>=0),
  volunteer_name text not null, volunteer_phone text not null, volunteer_alt_phone text,
  status case_status not null default 'pending_review',
  public_title text, public_description text, public_photo_path text, approved_target numeric check (approved_target>=0),
  category donation_category not null default 'animal_welfare',
  created_at timestamptz default now(), updated_at timestamptz default now());
create table rescue_case_files (id uuid primary key default gen_random_uuid(), case_id uuid references rescue_cases on delete cascade, kind text not null, storage_path text not null, created_at timestamptz default now());
create table donations (
  id uuid primary key default gen_random_uuid(), submission_code text unique not null default ('DN-'||upper(substr(gen_random_uuid()::text,1,8))),
  donor_name text not null, donor_phone text not null, amount numeric not null check (amount>0),
  category donation_category not null, case_id uuid references rescue_cases, upi_ref text not null,
  screenshot_path text, display_name_public boolean not null default false,
  status donation_status not null default 'pending_verification', verified_at timestamptz, verified_by uuid references auth.users,
  created_at timestamptz default now());
create unique index donations_upi_ref_uq on donations (lower(trim(upi_ref)));
create table expenses (id uuid primary key default gen_random_uuid(), amount numeric not null check (amount>0), category text not null, case_id uuid references rescue_cases, description text, approved boolean not null default false, created_at timestamptz default now());
create table financial_ledger (
  id uuid primary key default gen_random_uuid(), at timestamptz default now(),
  entry_type text not null check (entry_type in ('opening','donation','expense','refund_in','refund_out','reversal','adjustment')),
  category text, case_id uuid references rescue_cases, amount numeric not null,
  description text, donation_id uuid references donations, expense_id uuid references expenses,
  reverses uuid references financial_ledger, reason text, created_by uuid references auth.users default auth.uid());
create function ledger_immutable() returns trigger language plpgsql as $$ begin raise exception 'Ledger is append-only; post a reversal entry.'; end $$;
create trigger ledger_no_change before update or delete on financial_ledger for each row execute function ledger_immutable();
create table volunteer_enquiries (id uuid primary key default gen_random_uuid(), full_name text not null, phone text not null, email text, city text, interest text, experience text, message text, created_at timestamptz default now());
create table website_content (key text primary key, value jsonb not null, updated_at timestamptz default now());
create table notifications (id uuid primary key default gen_random_uuid(), type text not null, body text not null, ref_id uuid, is_read boolean default false, created_at timestamptz default now());
create table audit_logs (id bigserial primary key, actor uuid, action text not null, entity text, entity_id text, detail jsonb, at timestamptz default now());
create function is_founder() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from profiles where id=auth.uid() and role='founder') $$;
create function verify_donation(d uuid) returns void language plpgsql security definer set search_path=public as $$
declare r donations; begin
  if not is_founder() then raise exception 'forbidden'; end if;
  select * into r from donations where id=d and status='pending_verification' for update;
  if not found then raise exception 'not pending'; end if;
  update donations set status='verified', verified_at=now(), verified_by=auth.uid() where id=d;
  insert into financial_ledger(entry_type,category,case_id,amount,description,donation_id) values('donation',r.category::text,r.case_id,r.amount,'Verified donation '||r.submission_code,d);
  insert into audit_logs(actor,action,entity,entity_id) values(auth.uid(),'verify_donation','donations',d::text);
end $$;
create function available_balance() returns numeric language sql stable security definer set search_path=public as $$ select case when is_founder() then coalesce(sum(amount),0) end from financial_ledger $$;
create view public_campaigns as
select c.id, c.case_code, coalesce(c.public_title,c.animal_name) title, c.animal_type, c.location, c.public_description, c.public_photo_path,
  c.approved_target target, c.status, c.category, c.updated_at,
  coalesce((select sum(amount) from donations d where d.case_id=c.id and d.status='verified'),0) raised
from rescue_cases c where c.status in ('published','urgent','fully_funded','completed');
grant select on public_campaigns to anon, authenticated;
create function submit_donation(p_name text,p_phone text,p_amount numeric,p_cat donation_category,p_case uuid,p_ref text,p_public boolean) returns text language plpgsql security definer set search_path=public as $$
declare code text; begin
  if length(trim(p_ref))<6 then raise exception 'Invalid reference'; end if;
  insert into donations(donor_name,donor_phone,amount,category,case_id,upi_ref,display_name_public) values(trim(p_name),trim(p_phone),p_amount,p_cat,p_case,trim(p_ref),p_public) returning submission_code into code;
  insert into notifications(type,body) values('donation','New donation pending verification: '||code);
  return code; exception when unique_violation then raise exception 'This UPI reference was already submitted'; end $$;
grant execute on function submit_donation to anon, authenticated;
create function submit_volunteer(p_name text,p_phone text,p_email text,p_city text,p_interest text,p_exp text,p_msg text) returns void language plpgsql security definer set search_path=public as $$
begin insert into volunteer_enquiries(full_name,phone,email,city,interest,experience,message) values(p_name,p_phone,p_email,p_city,p_interest,p_exp,p_msg);
insert into notifications(type,body) values('volunteer','New volunteer enquiry from '||p_name); end $$;
grant execute on function submit_volunteer to anon, authenticated;
do $$ declare t text; begin
 foreach t in array array['profiles','team_access_settings','team_login_attempts','rescue_cases','rescue_case_files','donations','expenses','financial_ledger','volunteer_enquiries','website_content','notifications','audit_logs'] loop
  execute format('alter table %I enable row level security',t);
  if t not in ('profiles','team_access_settings','team_login_attempts','website_content','financial_ledger') then
   execute format('create policy founder_all on %I for all using (is_founder()) with check (is_founder())',t); end if;
 end loop; end $$;
create policy founder_ledger_read on financial_ledger for select using (is_founder());
create policy founder_ledger_add on financial_ledger for insert with check (is_founder());
create policy founder_profile on profiles for select using (id=auth.uid());
create policy content_public_read on website_content for select using (true);
create policy content_founder_write on website_content for all using (is_founder()) with check (is_founder());
insert into storage.buckets(id,name,public) values('private-docs','private-docs',false),('public-media','public-media',true) on conflict do nothing;
create policy docs_founder_read on storage.objects for select using (bucket_id='private-docs' and is_founder());
create policy media_founder_write on storage.objects for all using (bucket_id='public-media' and is_founder()) with check (bucket_id='public-media' and is_founder());
