import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'
import bcrypt from 'https://esm.sh/bcryptjs@2.4.3'
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'content-type, authorization, apikey' }
const J = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, 'content-type': 'application/json' } })
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  const ip = req.headers.get('x-forwarded-for') ?? 'unknown'
  const since = new Date(Date.now() - 15 * 60000).toISOString()
  const { count } = await db.from('team_login_attempts').select('*', { count: 'exact', head: true }).eq('ip', ip).gte('at', since)
  if ((count ?? 0) >= 8) return J({ error: 'Too many attempts. Try again later.' }, 429)
  const b = await req.json()
  const { data: s } = await db.from('team_access_settings').select('*').eq('id', 1).single()
  if (!s?.enabled || !(await bcrypt.compare(String(b.code ?? ''), s.code_hash))) {
    await db.from('team_login_attempts').insert({ ip }); return J({ error: 'Invalid access code' }, 401)
  }
  const c = b.case ?? {}
  if (!c.animal_type || !c.location || !c.condition || !c.description || !c.volunteer_name || !c.volunteer_phone || c.confirmed !== true) return J({ error: 'Missing required fields' }, 400)
  const allowed = ['animal_name','animal_type','location','condition','description','rescue_date','hospital','treatment_required','treatment_status','diagnosis','symptoms','treatment_given','treatment_pending','estimated_cost','volunteer_name','volunteer_phone','volunteer_alt_phone']
  const row: Record<string, unknown> = {}; for (const k of allowed) if (c[k] !== undefined && c[k] !== '') row[k] = c[k]
  const { data, error } = await db.from('rescue_cases').insert(row).select('id, case_code').single()
  if (error) return J({ error: error.message }, 400)
  await db.from('notifications').insert({ type: 'rescue_case', body: `New rescue case ${data.case_code}`, ref_id: data.id })
  return J({ caseCode: data.case_code, caseId: data.id })
})
