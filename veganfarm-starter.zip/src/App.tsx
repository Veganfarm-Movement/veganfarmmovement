import { NavLink, Route, Routes } from 'react-router-dom'
import Home from './pages/Home'; import Campaigns from './pages/Campaigns'; import Donate from './pages/Donate'; import Team from './pages/Team'
import Static from './pages/Static'
export default function App() {
  return (<>
    <header><nav aria-label="Main">
      <strong>VEGANFARM</strong>
      {[['/', 'Home'], ['/about', 'About'], ['/animal-welfare', 'Animal Welfare'], ['/campaigns', 'Live Campaigns'], ['/humanitarian', 'Humanitarian'], ['/education', 'Education'], ['/no-leather-on-campus', 'No Leather on Campus'], ['/contact', 'Contact']].map(([to, l]) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => isActive ? 'active' : ''}>{l}</NavLink>)}
      <NavLink to="/donate" className="btn">Donate</NavLink></nav></header>
    <main><Routes>
      <Route path="/" element={<Home />} /><Route path="/campaigns" element={<Campaigns />} /><Route path="/donate" element={<Donate />} />
      <Route path="/team" element={<Team />} /><Route path="*" element={<Static />} />
    </Routes></main>
    <footer style={{ borderTop: '1px solid var(--b)', color: 'var(--t2)', fontSize: 14 }}>
      <p>VEGANFARM Movement is an animal welfare and humanitarian initiative of Niswarth Seva 1008 Charitable Trust. It is not a separately registered legal entity.</p>
      <p><a href="mailto:veganfarmmovement@gmail.com">Email</a> · <a href="https://wa.me/919823762859">WhatsApp</a> · <a href="https://www.instagram.com/veganfarm_movement">Instagram</a> · <a href="/team">Team Portal</a></p></footer></>)
}
