import { useLocation } from 'react-router-dom'
export default function Static() { const p = useLocation().pathname
  return <><h1>{p.slice(1).replace(/-/g, ' ') || 'Page'}</h1><p>This page is a stub. Its content from the brief has not been written yet.</p></> }
