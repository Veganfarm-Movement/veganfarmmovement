import { Link } from 'react-router-dom'
export default function Home() { return (<>
  <section className="hero"><h1>Every life matters. Every act of compassion counts.</h1>
    <p>Working towards a more compassionate world through animal welfare, humanitarian support, education and collective action.</p>
    <Link className="btn" to="/donate">Support our mission</Link></section>
  <div className="photo-slot" role="img" aria-label="Photo placeholder">Founder: upload a genuine rescue photograph here</div>
  <p>VEGANFARM Movement is an animal welfare and humanitarian initiative of Niswarth Seva 1008 Charitable Trust.</p></>) }
