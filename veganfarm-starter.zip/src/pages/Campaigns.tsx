import { useEffect, useState } from 'react'; import { supabase } from '../lib/supabase'; import { Link } from 'react-router-dom'
type C = { id: string; title: string; location: string; public_description: string; target: number; raised: number; status: string; updated_at: string }
export default function Campaigns() {
  const [rows, setRows] = useState<C[] | null>(null); const [err, setErr] = useState('')
  useEffect(() => { supabase.from('public_campaigns').select('*').order('updated_at', { ascending: false }).then(({ data, error }) => error ? setErr(error.message) : setRows(data as C[])) }, [])
  if (err) return <p className="err" role="alert">Could not load campaigns: {err}</p>
  if (!rows) return <p>Loading…</p>
  if (!rows.length) return <p>No campaigns are published right now.</p>
  return <div className="grid">{rows.map(c => { const pct = c.target ? Math.min(100, Math.round(c.raised / c.target * 100)) : 0
    return <article className="card" key={c.id}><h3>{c.title}</h3><p>{c.location}</p><p>{c.public_description}</p>
      <div className="bar"><i style={{ width: pct + '%' }} /></div>
      <p>₹{c.raised} verified of ₹{c.target ?? '—'} · remaining ₹{Math.max(0, (c.target ?? 0) - c.raised)} · {c.status}</p>
      <small>Updated {new Date(c.updated_at).toLocaleDateString()}</small><br /><Link className="btn" to={`/donate?case=${c.id}`}>Support this case</Link></article> })}</div>
}
