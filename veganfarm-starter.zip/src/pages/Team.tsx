import { FormEvent, useState } from 'react'
export default function Team() {
  const [out, setOut] = useState(''); const [err, setErr] = useState('')
  async function go(e: FormEvent<HTMLFormElement>) { e.preventDefault(); setErr(''); const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, any>
    const { code, ...c } = f; c.confirmed = true
    const r = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/team-submit`, { method: 'POST', headers: { 'content-type': 'application/json', apikey: import.meta.env.VITE_SUPABASE_ANON_KEY }, body: JSON.stringify({ code, case: c }) })
    const j = await r.json(); if (!r.ok) setErr(j.error); else setOut(`Your rescue case has been submitted. Case ID: ${j.caseCode}. The Founder will review it.`) }
  return (<><h1>Team Portal — submit a rescue case</h1>
    <form onSubmit={go}><label>Team access code<input name="code" type="password" required autoComplete="off" /></label>
      <label>Animal name<input name="animal_name" /></label><label>Animal type<select name="animal_type"><option value="dog">Dog</option><option value="cat">Cat</option><option value="cow">Cow</option><option value="other">Other</option></select></label>
      <label>Location<input name="location" required /></label><label>Current condition<input name="condition" required /></label>
      <label>Situation description<textarea name="description" required /></label><label>Hospital / clinic<input name="hospital" /></label>
      <label>Diagnosis<input name="diagnosis" /></label><label>Treatment required<input name="treatment_required" /></label>
      <label>Estimated cost (₹, if known)<input name="estimated_cost" type="number" min="0" /></label>
      <p><em>Photo and document upload is not built yet.</em></p>
      <label>Volunteer full name<input name="volunteer_name" required /></label><label>Contact number<input name="volunteer_phone" required /></label>
      <label>Alternative number (optional)<input name="volunteer_alt_phone" /></label>
      <label><input type="checkbox" required style={{ width: 'auto' }} /> I confirm the information is accurate.</label><br /><button className="btn">Submit case</button></form>
    {out && <p className="ok" role="status">{out}</p>}{err && <p className="err" role="alert">{err}</p>}</>)
}
