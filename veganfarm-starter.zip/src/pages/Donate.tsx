import { FormEvent, useState } from 'react'; import { useSearchParams } from 'react-router-dom'; import { supabase } from '../lib/supabase'
export default function Donate() {
  const [q] = useSearchParams(); const [msg, setMsg] = useState(''); const [err, setErr] = useState('')
  async function go(e: FormEvent<HTMLFormElement>) { e.preventDefault(); setErr(''); const f = new FormData(e.currentTarget)
    const { data, error } = await supabase.rpc('submit_donation', { p_name: f.get('name'), p_phone: f.get('phone'), p_amount: Number(f.get('amount')), p_cat: f.get('cat'), p_case: q.get('case'), p_ref: f.get('ref'), p_public: f.get('pub') === 'yes' })
    if (error) setErr(error.message); else setMsg(`Submitted (${data}). Your donation is pending verification and is not yet counted publicly.`) }
  return (<><h1>Donate</h1>
    <p>Donations associated with VEGANFARM Movement's charitable initiatives are received through Niswarth Seva 1008 Charitable Trust.</p>
    <p>UPI ID: <strong>niswarthseva1008@oksbi</strong></p>
    <div className="photo-slot">Official Trust QR code — Founder to upload</div>
    <form onSubmit={go}>
      <label>Full name<input name="name" required /></label><label>Contact number<input name="phone" required pattern="[0-9+ ]{10,15}" /></label>
      <label>Amount (₹)<input name="amount" type="number" min="1" required /></label>
      <label>Category<select name="cat"><option value="animal_welfare">Animal Welfare</option><option value="human_welfare">Human Welfare</option></select></label>
      <label>UPI transaction reference<input name="ref" required minLength={6} /></label>
      <label>Public display<select name="pub"><option value="no">Anonymous</option><option value="yes">Display my name</option></select></label>
      <label><input type="checkbox" required style={{ width: 'auto' }} /> I confirm these details are accurate.</label><br />
      <button className="btn">Submit for verification</button></form>
    {msg && <p className="ok" role="status">{msg}</p>}{err && <p className="err" role="alert">{err}</p>}
    <h2>Donor documentation & tax enquiries</h2><p>For receipts, 80G and 12A-related information, contact Niswarth Seva 1008 Charitable Trust directly.</p>
    <a className="btn" href="https://wa.me/919823762859">Contact Trust on WhatsApp</a></>)
}
