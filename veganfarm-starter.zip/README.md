# VEGANFARM Movement — starter codebase (partial, untested)
React + TypeScript + Vite + Supabase.
## Setup
1. `npm install`; copy `.env.example` to `.env`; fill the Supabase URL and anon key.
2. Supabase SQL editor: run `supabase/migrations/001_schema.sql`.
3. Founder: create a user in Supabase Auth (email + strong password), then `insert into profiles(id,full_name) values('<uid>','Harshit Dedhia');`
4. Team code: bcrypt-hash the code locally, then `insert into team_access_settings(code_hash) values('<hash>');`. Never commit the code or hash.
5. `supabase functions deploy team-submit` (service-role key is injected for functions; never put it in `.env`).
6. `npm run dev`; deploy to Vercel/Netlify with the two VITE_ variables.
## Not built yet
Founder dashboard UI, file uploads, CMS, notifications UI, legal pages, real page content, tests.
